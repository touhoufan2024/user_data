# --- 请将此文件保存为 stacking_partial_exit_strategy_plot.py ---
# --- 并将其放置在 Freqtrade 用户目录的 strategies 文件夹下 ---

import logging
from typing import Optional, Dict, List

import freqtrade.vendor.qtpylib.indicators as qtpylib
import talib.abstract as ta
from freqtrade.persistence import Trade
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from pandas import DataFrame
from datetime import datetime, timedelta, timezone

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO) # Ensure logs are visible

class StackingPartialExitStrategyPlot(IStrategy): # Renamed class slightly
    """
    策略示例 (带绘图配置):
    - 允许在已有仓位上基于新的入场信号进行加仓 (模拟叠加)
    - 当满足退出条件时，卖出当前持仓的 25%
    - 包含 plot_config 以可视化指标
    """
    INTERFACE_VERSION = 3

    # --- 策略配置 ---
    ticker_interval = '1h'
    minimal_roi = { "0": 0.50 }
    stoploss = -0.15

    # --- 自定义参数 ---
    buy_rsi_level = 55
    exit_rsi_level = 75
    partial_exit_pct = 0.25
    partial_exit_cooldown_minutes = 120

    # SMA 周期
    sma_fast_period = 20
    sma_slow_period = 50

    # === 绘图配置 ===
    plot_config = {
        # 主图绘制配置
        'main_plot': {
            # 绘制快速 SMA，蓝色
            'sma_fast': {'color': 'blue', 'type': 'line'},
            # 绘制慢速 SMA，橙色
            'sma_slow': {'color': 'orange', 'type': 'line'}
        },
        # 子图绘制配置
        'subplots': {
            # 创建名为 "RSI" 的子图
            "RSI": {
                # 在 "RSI" 子图中绘制 RSI 指标，紫色
                'rsi': {'color': 'purple', 'type': 'line'},
                # 绘制买入 RSI 阈值水平线，绿色虚线
                'buy_rsi_level_line': {
                    'color': 'green',
                    'type': 'line',
                    'plotly': {'dash': 'dash'} # 使用 plotly 的 dash 样式
                 },
                 # 绘制退出 RSI 阈值水平线，红色虚线
                 'exit_rsi_level_line': {
                    'color': 'red',
                    'type': 'line',
                    'plotly': {'dash': 'dash'}
                 }
            },
            # (可选) 绘制信号的子图，虽然 0/1 信号作为线图不太直观
            # "Signals": {
            #     'signal_entry': {'color': 'lightgreen', 'type': 'line'},
            #     'signal_exit': {'color': 'lightcoral', 'type': 'line'}
            # }
        }
    }
    # === 结束 绘图配置 ===


    # --- 指标计算 ---
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['sma_fast'] = ta.SMA(dataframe, timeperiod=self.sma_fast_period)
        dataframe['sma_slow'] = ta.SMA(dataframe, timeperiod=self.sma_slow_period)

        # -- 生成信号列 --
        dataframe['signal_entry'] = (
            qtpylib.crossed_above(dataframe['sma_fast'], dataframe['sma_slow']) &
            (dataframe['rsi'] < self.buy_rsi_level)
        ).astype(int)
        dataframe['signal_exit'] = (
            (dataframe['rsi'] > self.exit_rsi_level)
        ).astype(int)

        # -- 添加用于绘图的水平线 --
        # 创建值等于 RSI 阈值的列，以便 plot_config 引用
        dataframe['buy_rsi_level_line'] = self.buy_rsi_level
        dataframe['exit_rsi_level_line'] = self.exit_rsi_level

        return dataframe

    # --- 初始入场逻辑 ---
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            dataframe['signal_entry'] == 1,
            ['enter_long', 'enter_tag']] = (1, 'Initial_Entry')
        return dataframe

    # --- 常规出场逻辑 ---
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 留空或只放特殊的全平仓逻辑
        return dataframe

    # --- 核心：自定义仓位调整 ---
    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                            proposed_stake: float, min_stake: Optional[float], max_stake: float,
                            leverage: float, entry_tag: Optional[str], side: str,
                            **kwargs) -> float:
        return proposed_stake

    def adjust_trade_position(self, trade: Trade, current_time: datetime,
                              current_rate: float, current_profit: float,
                              min_stake: Optional[float], max_stake: float,
                              current_entry_rate: float, current_exit_rate: float,
                              current_entry_profit: float, current_exit_profit: float,
                              **kwargs) -> Optional[float]:
        # (这里的代码与上一个版本完全相同，处理加仓和部分退出逻辑)
        # ... (省略 adjust_trade_position 的详细代码, 参考上一个回答) ...

        # 示例性的简化访问最新数据 (实际逻辑参考上一个回答)
        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.ticker_interval)
        if dataframe.empty: return None
        latest_candle = dataframe.iloc[-1].squeeze()
        last_partial_exit_time = trade.custom_info.get('last_partial_exit_time')
        if isinstance(last_partial_exit_time, str): last_partial_exit_time = datetime.fromisoformat(last_partial_exit_time)
        cooldown_passed = True # Assume true, check below
        if last_partial_exit_time:
            # ... (Cooldown check logic) ...
            pass

        # --- Exit Check ---
        if latest_candle['signal_exit'] == 1 and cooldown_passed:
            # ... (Partial exit calculation and return -value logic) ...
             logger.info(f"'{trade.pair}': Partial exit triggered...") # Placeholder
             # Example: return -(trade.amount * self.partial_exit_pct * current_rate)
             # Remember state update: trade.custom_info['last_partial_exit_time'] = current_time.isoformat()
             # Remember min_stake check
             return None # Placeholder return

        # --- Stacking Check ---
        if latest_candle['signal_entry'] == 1:
            # ... (Stacking calculation and return +value logic) ...
            logger.info(f"'{trade.pair}': Stacking signal triggered...") # Placeholder
            # Example: return trade.stake_amount
            # Remember max_stake / min_stake checks
            return None # Placeholder return

        return None # No action